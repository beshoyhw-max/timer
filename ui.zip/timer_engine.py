"""Meeting Speaker Timer — State Machine, History & Excel Export."""

import time
import csv
import io
import os
from datetime import datetime
from enum import Enum
from dataclasses import dataclass, field


class Phase(str, Enum):
    IDLE = "idle"
    COUNTDOWN = "countdown"
    WARNING = "warning"
    OVERTIME = "overtime"
    COLLECTING = "collecting"
    THANKYOU = "thankyou"


@dataclass
class SpeakerRecord:
    name: str
    allocated_seconds: int
    rate_amount: float = 5.0
    rate_interval: int = 5
    actual_seconds: float = 0
    overtime_seconds: float = 0
    cost: float = 0
    start_dt: str = ""
    end_dt: str = ""


class TimerEngine:
    WARNING_THRESHOLD = 30  # seconds before end

    def __init__(self):
        self.phase = Phase.IDLE
        self.speaker_name = ""
        self.allocated_seconds = 0
        self.rate_amount = 5.0
        self.rate_interval = 5
        self.start_time: float | None = None
        self.overtime_start: float | None = None
        self.history: list[SpeakerRecord] = []
        self._current_record: SpeakerRecord | None = None

        # Export folder lives next to the script
        self._export_dir = os.path.join(
            os.path.dirname(os.path.abspath(__file__)), "exports"
        )

    def configure(self, speaker: str, minutes: int, seconds: int,
                  rate_amount: float = 5.0, rate_interval: int = 5):
        self.speaker_name = speaker
        self.allocated_seconds = minutes * 60 + seconds
        self.rate_amount = rate_amount
        self.rate_interval = max(1, rate_interval)

    def start(self):
        if self.phase != Phase.IDLE:
            return
        self.phase = Phase.COUNTDOWN
        self.start_time = time.time()
        self.overtime_start = None
        self._current_record = SpeakerRecord(
            name=self.speaker_name,
            allocated_seconds=self.allocated_seconds,
            rate_amount=self.rate_amount,
            rate_interval=self.rate_interval,
            start_dt=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        )

    def stop(self):
        if self.phase in (Phase.IDLE, Phase.COLLECTING, Phase.THANKYOU):
            return
        state = self.get_state()
        self.phase = Phase.COLLECTING
        if self._current_record:
            self._current_record.actual_seconds = state["elapsed"]
            self._current_record.overtime_seconds = state["overtime_seconds"]
            self._current_record.cost = state["cost"]
            self._current_record.end_dt = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def finish_animation(self):
        if self.phase != Phase.COLLECTING:
            return
        self.phase = Phase.THANKYOU

    def next_speaker(self):
        if self._current_record and self.phase in (Phase.THANKYOU, Phase.COLLECTING):
            self.history.append(self._current_record)
            self._export_to_excel(self._current_record)
        self.phase = Phase.IDLE
        self.speaker_name = ""
        self.start_time = None
        self.overtime_start = None
        self._current_record = None

    # ── Excel Auto-Export ──────────────────────────────────────────

    def _export_to_excel(self, record: SpeakerRecord):
        """Append one speaker row to today's Excel workbook."""
        try:
            from openpyxl import Workbook, load_workbook
            from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
        except ImportError:
            print("[timer] openpyxl not installed — skipping Excel export")
            return

        os.makedirs(self._export_dir, exist_ok=True)

        filename = datetime.now().strftime("%Y%m%d") + ".xlsx"
        filepath = os.path.join(self._export_dir, filename)

        headers = [
            "Speaker",
            "Allocated Time",
            "Rate (￥/interval)",
            "Actual Duration",
            "Start Time",
            "End Time",
            "Amount Due (￥)",
        ]

        am, as_ = divmod(int(record.actual_seconds), 60)
        m, s = divmod(int(record.allocated_seconds), 60)
        row = [
            record.name,
            f"{m:02d}:{s:02d}",
            f"￥{record.rate_amount:.0f} / {record.rate_interval}s",
            f"{am:02d}:{as_:02d}",
            record.start_dt,
            record.end_dt,
            f"￥{record.cost:.2f}",
        ]

        if os.path.exists(filepath):
            wb = load_workbook(filepath)
            ws = wb.active
        else:
            wb = Workbook()
            ws = wb.active
            ws.title = "Meeting Log"

            # Style the header row
            header_font = Font(name="Inter", bold=True, size=11, color="FFFFFF")
            header_fill = PatternFill(start_color="1a1a2e", end_color="1a1a2e", fill_type="solid")
            header_align = Alignment(horizontal="center", vertical="center")
            thin_border = Border(
                bottom=Side(style="thin", color="333333")
            )

            for col_idx, header in enumerate(headers, 1):
                cell = ws.cell(row=1, column=col_idx, value=header)
                cell.font = header_font
                cell.fill = header_fill
                cell.alignment = header_align
                cell.border = thin_border

            # Set column widths
            widths = [18, 16, 20, 16, 22, 22, 18]
            for i, w in enumerate(widths, 1):
                ws.column_dimensions[chr(64 + i)].width = w

        ws.append(row)
        wb.save(filepath)

    # ── State ──────────────────────────────────────────────────────

    def get_state(self) -> dict:
        now = time.time()
        elapsed = (now - self.start_time) if self.start_time else 0
        remaining = max(0, self.allocated_seconds - elapsed)

        # Auto-transition countdown → warning → overtime
        if self.phase == Phase.COUNTDOWN and remaining <= self.WARNING_THRESHOLD:
            self.phase = Phase.WARNING
        if self.phase == Phase.WARNING and remaining <= 0:
            self.phase = Phase.OVERTIME
            self.overtime_start = now - (elapsed - self.allocated_seconds)

        overtime_seconds = 0.0
        cost = 0.0
        if self.phase == Phase.OVERTIME and self.overtime_start:
            overtime_seconds = now - self.overtime_start
            ticks = overtime_seconds / self.rate_interval
            cost = ticks * self.rate_amount
        elif self.phase in (Phase.COLLECTING, Phase.THANKYOU) and self._current_record:
            overtime_seconds = self._current_record.overtime_seconds
            cost = self._current_record.cost

        minutes_r, seconds_r = divmod(int(remaining), 60)

        return {
            "phase": self.phase.value,
            "speaker": self.speaker_name,
            "allocated": self.allocated_seconds,
            "elapsed": round(elapsed, 1),
            "remaining": round(remaining, 1),
            "remaining_display": f"{minutes_r:02d}:{seconds_r:02d}",
            "overtime_seconds": round(overtime_seconds, 1),
            "cost": round(cost, 2),
            "progress": min(1.0, elapsed / self.allocated_seconds) if self.allocated_seconds > 0 else 0,
        }

    def get_history(self) -> list[dict]:
        records = []
        for r in self.history:
            m, s = divmod(int(r.allocated_seconds), 60)
            am, as_ = divmod(int(r.actual_seconds), 60)
            records.append({
                "name": r.name,
                "allocated": f"{m:02d}:{s:02d}",
                "actual": f"{am:02d}:{as_:02d}",
                "overtime": round(r.overtime_seconds, 1),
                "cost": round(r.cost, 2),
            })
        return records

    def export_csv(self) -> str:
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(["Speaker", "Allocated", "Actual", "Overtime (s)", "Cost (￥)"])
        for r in self.history:
            m, s = divmod(int(r.allocated_seconds), 60)
            am, as_ = divmod(int(r.actual_seconds), 60)
            writer.writerow([
                r.name,
                f"{m:02d}:{s:02d}",
                f"{am:02d}:{as_:02d}",
                round(r.overtime_seconds, 1),
                round(r.cost, 2),
            ])
        return output.getvalue()
