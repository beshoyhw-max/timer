"""Meeting Speaker Timer — PyWebView Desktop App."""

import os
import time

import webview

from timer_engine import TimerEngine

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UI_DIR = os.path.join(BASE_DIR, "ui")


class TimerAPI:
    def __init__(self):
        self.engine = TimerEngine()

    def configure(self, speaker: str, minutes: int, seconds: int,
                  rate_amount: float = 5.0, rate_interval: int = 5):
        self.engine.configure(speaker, minutes, seconds, rate_amount, rate_interval)

    def start_timer(self):
        self.engine.start()

    def stop_timer(self):
        self.engine.stop()

    def finish_animation(self):
        self.engine.finish_animation()

    def next_speaker(self):
        self.engine.next_speaker()

    def get_state(self):
        return self.engine.get_state()

    def get_history(self):
        return self.engine.get_history()

    def export_csv(self):
        return self.engine.export_csv()

    def set_size(self, width, height):
        for w in webview.windows:
            w.resize(int(width), int(height))
            break

    def go_fullscreen(self):
        for w in webview.windows:
            w.toggle_fullscreen()
            break

    def go_floating(self, panel_open=False):
        for w in webview.windows:
            w.toggle_fullscreen()
            time.sleep(0.15)
            w.resize(500, 480 if panel_open else 120)
            break


def main():
    api = TimerAPI()

    window = webview.create_window(
        title="Meeting Timer",
        url=os.path.join(UI_DIR, "index.html"),
        js_api=api,
        width=500,
        height=120,
        min_size=(300, 60),
        frameless=True,
        easy_drag=True,
        on_top=True,
        resizable=True,
        background_color="#0a0a0f",
    )

    def on_start():
        """Force initial window size to correct glitchy startup width."""
        time.sleep(0.1)  # Wait for window to fully manifest
        window.resize(500, 120)

    webview.start(on_start, debug=True)


if __name__ == "__main__":
    main()
